//
//  ModelAdapter.h
//  NormalProblem
//
//  Created by YouXianMing on 15/7/25.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "BusinessCardAdapter.h"

/**
 *  类适配器
 */
@interface ModelAdapter : BusinessCardAdapter

@end
