//
//  FadeAnimationView.m
//  DesignPatternFundamental
//
//  Created by YouXianMing on 15/7/20.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "FadeAnimationView.h"

@implementation FadeAnimationView

- (void)fadeAnimated:(BOOL)animated {

    // todo
}

- (void)changeToNormalStateAnimated:(BOOL)animated duration:(NSTimeInterval)duration {
    
    [self fadeAnimated:animated];
}

- (void)changeToDisableStateAnimated:(BOOL)animated duration:(NSTimeInterval)duration {
    
    // todo
}

- (void)changeToHighlightStateAnimated:(BOOL)animated duration:(NSTimeInterval)duration {
    
    // todo
}

@end
