//
//  AnimationView.h
//  DesignPatternFundamental
//
//  Created by YouXianMing on 15/7/20.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FadeAnimationView.h"

@interface AnimationView : UIView

@property (nonatomic, strong) FadeAnimationView *fadeAnimationView;

/**
 *  切换到出错状态
 *
 *  @param animated 是否执行动画
 *  @param duration 动画持续时间
 */
- (void)changeToErrorStateAnimated:(BOOL)animated duration:(NSTimeInterval)duration;

@end
