//
//  ViewController.m
//  DesignPatternFundamental
//
//  Created by YouXianMing on 15/7/20.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "ViewController.h"
#import "BaseAnimationView.h"
#import "FadeAnimationView.h"
#import "ScaleAnimationView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    BaseAnimationView *animationView = [[ScaleAnimationView alloc] init];
    [animationView changeToDisableStateAnimated:YES duration:0.5f];
}

@end
