//
//  ScaleAnimationView.h
//  DesignPatternFundamental
//
//  Created by YouXianMing on 15/7/20.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "BaseAnimationView.h"

@interface ScaleAnimationView : BaseAnimationView

@end
