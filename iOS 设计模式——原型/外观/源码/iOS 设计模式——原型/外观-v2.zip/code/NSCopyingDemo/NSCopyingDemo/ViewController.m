//
//  ViewController.m
//  NSCopyingDemo
//
//  Created by YouXianMing on 15/8/16.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "ViewController.h"
#import "StudentModel.h"
#import "ClassModel.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];

    StudentModel *stu1 = [[StudentModel alloc] init];
    stu1.name          = @"小明";
    
    StudentModel *stu2 = stu1.copy;
    
    ClassModel *class1 = [[ClassModel alloc] init];
    class1.className   = @"班级1";
    class1.students    = @[stu1, stu2];
    
    ClassModel *class2 = class1.copy;
    NSLog(@"%@ %@", class1, class2);
    
    NSLog(@"%@", class1.students);
    NSLog(@"%@", class2.students);
}

@end
