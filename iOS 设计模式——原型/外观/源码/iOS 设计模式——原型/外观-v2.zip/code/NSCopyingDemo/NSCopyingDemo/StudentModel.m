//
//  StudentModel.m
//  NSCopyingDemo
//
//  Created by YouXianMing on 15/8/16.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "StudentModel.h"

@implementation StudentModel

- (void)copyOperationWithObject:(StudentModel *)object {
    
    object.name = self.name;
    object.age  = self.age;
}

@end
