//
//  StudentModel.h
//  NSCopyingDemo
//
//  Created by YouXianMing on 15/8/16.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "BasCopyObject.h"

@interface StudentModel : BasCopyObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSNumber *age;

@end
