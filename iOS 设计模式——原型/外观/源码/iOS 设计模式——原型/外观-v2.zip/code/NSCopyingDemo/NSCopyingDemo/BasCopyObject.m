//
//  BasCopyObject.m
//  NSCopyingDemo
//
//  Created by YouXianMing on 15/8/16.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "BasCopyObject.h"

@implementation BasCopyObject

- (id)copyWithZone:(NSZone *)zone {

    BasCopyObject *copyObject = [[self class] allocWithZone:zone];
    
    // 赋值操作作业
    [self copyOperationWithObject:copyObject];
    
    return copyObject;
}

- (void)copyOperationWithObject:(id)object {

}

@end
