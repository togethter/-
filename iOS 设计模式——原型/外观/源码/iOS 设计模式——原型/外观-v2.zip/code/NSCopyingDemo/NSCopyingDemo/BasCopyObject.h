//
//  BasCopyObject.h
//  NSCopyingDemo
//
//  Created by YouXianMing on 15/8/16.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BasCopyObject : NSObject <NSCopying>

/**
 *  == 子类不要重载 ==
 *
 *  @return 复制的对象
 */
- (id)copyWithZone:(NSZone *)zone;

/**
 *  == 由子类重载实现 ==
 *
 *  复制(赋值操作)
 *
 *  @param object 已经复制的对象
 */
- (void)copyOperationWithObject:(id)object;

@end
