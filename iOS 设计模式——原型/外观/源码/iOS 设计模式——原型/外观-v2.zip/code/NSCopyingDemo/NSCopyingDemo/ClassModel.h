//
//  ClassModel.h
//  NSCopyingDemo
//
//  Created by YouXianMing on 15/8/16.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "BasCopyObject.h"

@interface ClassModel : BasCopyObject

@property (nonatomic, strong) NSString  *className;
@property (nonatomic, strong) NSArray   *students;

@end
