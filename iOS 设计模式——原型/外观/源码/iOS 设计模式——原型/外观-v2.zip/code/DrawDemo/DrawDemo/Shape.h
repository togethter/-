//
//  Shape.h
//  DrawDemo
//
//  Created by YouXianMing on 15/8/16.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Shape : NSObject

/**
 *  最终绘制图形
 */
- (void)draw;

@end
