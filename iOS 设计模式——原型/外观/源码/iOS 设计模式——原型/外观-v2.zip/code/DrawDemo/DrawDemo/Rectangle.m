//
//  Rectangle.m
//  DrawDemo
//
//  Created by YouXianMing on 15/8/16.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "Rectangle.h"

@implementation Rectangle

- (void)draw {

    // 具体的实现
}

@end
