//
//  iPhoneDevice.h
//  FactoryPattern
//
//  Created by YouXianMing on 15/9/5.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "BaseDevie.h"

@interface iPhoneDevice : BaseDevie

/**
 *  指纹识别
 */
- (void)fingerprintIndetification;

@end
