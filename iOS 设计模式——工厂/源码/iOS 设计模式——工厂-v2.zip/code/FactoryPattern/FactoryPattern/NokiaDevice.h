//
//  NokiaDevice.h
//  FactoryPattern
//
//  Created by YouXianMing on 15/9/5.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "BaseDevie.h"

@interface NokiaDevice : BaseDevie

/**
 *  敲核桃
 */
- (void)knockWalnut;

@end
