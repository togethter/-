//
//  AndroidDevice.h
//  FactoryPattern
//
//  Created by YouXianMing on 15/9/5.
//  Copyright (c) 2015年 YouXianMing. All rights reserved.
//

#import "BaseDevie.h"

@interface AndroidDevice : BaseDevie

/**
 *  定制主题
 */
- (void)customTheme;

@end
